from flask import Flask, request
import json
import warnings
from flask_cors import CORS
import winreg as reg
import pymongo
from waitress import serve

import getData
import Login
import setData

client = pymongo.MongoClient()
db = client['barge2']


def addToReg():
    key = reg.OpenKey(reg.HKEY_CURRENT_USER , "Software\Microsoft\Windows\CurrentVersion\Run" ,0 , reg.KEY_ALL_ACCESS)
    reg.SetValueEx(key ,"ibargeFlask" , 0 , reg.REG_SZ , __file__)
    reg.CloseKey(key)

addToReg()
warnings.filterwarnings("ignore")
app = Flask(__name__)
CORS(app)


@app.route('/getmenu',methods=['POST'])
def getmenu():
    return getData.getMenu()

@app.route('/gethomemenu',methods=['POST'])
def gethomemenu():
    return getData.getHomeMenu()

@app.route('/getcaptcha',methods=['POST'])
def getcaptcha():
    return getData.getCaptcha()

@app.route('/applyphone',methods=['POST'])
def applyphone():
    data = request.get_json()
    return Login.applyPhone(data)

@app.route('/applycode',methods=['POST'])
def applycode():
    data = request.get_json()
    return Login.applyCode(data)

@app.route('/loginbypua',methods=['POST'])
def loginbypua():
    data = request.get_json()
    return Login.loginByPUA(data)

@app.route('/getuserbypua',methods=['POST'])
def getuserbypua():
    data = request.get_json()
    return Login.getUserByPUA(data)

@app.route('/setprofile',methods=['POST'])
def setprofile():
    data = request.get_json()
    return setData.setProfile(data)


if __name__ == '__main__':
    #serve(app, host="0.0.0.0", port=8080)
    app.run(host='0.0.0.0', debug=True)